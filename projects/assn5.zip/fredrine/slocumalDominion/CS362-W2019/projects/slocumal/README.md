Allan Slocum - slocumal
